# -*- coding: utf-8 -*-
import sys
import urllib.parse
import urllib.request
import xbmcplugin
import xbmcgui

# Define your playlists here (name : URL or local path)
PLAYLISTS = {
    "TV Pass": "https://tvpass.org/playlist/m3u",
    "Xumo": "https://www.apsattv.com/xumo.m3u",
    "Local Now": "https://www.apsattv.com/localnow.m3u",
    "US Channels": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us.m3u",
    "US Cable": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_tvpass.m3u",
    "US moveonejoy": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_moveonjoy.m3u",
    "US Stirr": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_stirr.m3u",
    "Roku TV": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_roku.m3u",
    "Samsung TV": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_samsung.m3u",
    "Local News": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_local.m3u",
    "Plex TV": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_plex.m3u",
    "Pluto TV": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_pluto.m3u",
    "All Channels": "https://iptv-org.github.io/iptv/index.m3u",
}

def build_url(query):
    """Build a Kodi plugin URL with query parameters"""
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def fetch_url(url):
    """Fetch text content from a URL using urllib"""
    try:
        with urllib.request.urlopen(url) as response:
            return response.read().decode('utf-8', errors='ignore')
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Could not load playlist:\n{e}")
        return None

def list_playlists():
    """Show the available M3U playlists"""
    for name, url in PLAYLISTS.items():
        li = xbmcgui.ListItem(label=name)
        li.setArt({"icon": "DefaultFolder.png"})
        u = build_url({'action': 'list_channels', 'playlist': url})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def list_channels(playlist_url):
    """Parse an M3U playlist and show channels"""
    content = fetch_url(playlist_url)
    if not content:
        xbmcplugin.endOfDirectory(addon_handle)
        return

    lines = content.splitlines()
    channel_name = None

    for line in lines:
        line = line.strip()
        if line.startswith('#EXTINF'):
            channel_name = line.split(',')[-1].strip()
        elif line.startswith('http'):
            li = xbmcgui.ListItem(label=channel_name)
            li.setInfo('video', {'title': channel_name})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=line, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

# Entry point
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])

action = args.get('action', None)

if action is None:
    list_playlists()
elif action[0] == 'list_channels':
    list_channels(args['playlist'][0])
